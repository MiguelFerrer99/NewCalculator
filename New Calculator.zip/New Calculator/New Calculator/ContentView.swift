//
//  ContentView.swift
//  New Calculator
//
//  Created by Miguel Ferrer Fornali on 12/10/2020.
//

import SwiftUI

struct ContentView: View {
    
    @State private var firstNumber = 0.0
    @State private var secondNumber = 0.0
    @State private var operand = ""
    @State private var calculatorText = "0"
    @State private var detailedCalculatorText = ""
    @State private var isTypingNumber = false
    @State private var operands = ["+","-","x","/"]
    @State private var detailedCalculatorTextVisible = true
    @State private var limitOfDigits = 13
    @State private var limitOfDetailedDigits = 20
    
    var body: some View {
        
        VStack {
            TextField("0", text: $calculatorText)
                .multilineTextAlignment(.trailing)
                .font(.custom("Arial", size: 80.0))
                .disabled(true)
                .minimumScaleFactor(0.6)
                .padding(.trailing, 20.0)
            
            TextField("", text: $detailedCalculatorText)
                .multilineTextAlignment(.trailing)
                .font(.custom("Arial", size: CGFloat(40.0)))
                .disabled(true)
                .opacity(detailedCalculatorTextVisible ? 1 : 0)
                .padding(.trailing, 20.0)
                .minimumScaleFactor(0.8)
            
            Spacer()

            HStack {
                Button(action: {
                    self.Ctapped()
                }) {
                    Text("C")
                        .foregroundColor(.blue)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color(UIColor(named: "OperandsColor")!)) //Using named color
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.copyTapped()
                }) {
                    Text("COPY")
                        .font(.custom("Arial", size: 20.0))
                        .bold()
                        .foregroundColor(.blue)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color(UIColor(named: "OperandsColor")!)) //Using named color
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.deleteTapped()
                }) {
                    Text("⌫")
                        .foregroundColor(.blue)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color(UIColor(named: "OperandsColor")!)) //Using named color
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.operandTapped("/")
                }) {
                    Text("÷")
                        .foregroundColor(.blue)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color(UIColor(named: "OperandsColor")!)) //Using named color
                        .cornerRadius(50.0)
                        .font(.custom("Arial", size: 50.0))
                }
            }.padding(.leading, 10).padding(.trailing, 10)
            .font(.largeTitle)
            
            HStack {
                Button(action: {
                    self.digitTapped("7")
                }) {
                    Text("7")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.digitTapped("8")
                }) {
                    Text("8")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.digitTapped("9")
                }) {
                    Text("9")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.operandTapped("x")
                }) {
                    Text("✕")
                        .foregroundColor(.blue)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color(UIColor(named: "OperandsColor")!)) //Using named color
                        .cornerRadius(50.0)
                }
            }.padding(.leading, 10).padding(.trailing, 10)
            .font(.largeTitle)
            
            HStack {
                Button(action: {
                    self.digitTapped("4")
                }) {
                    Text("4")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.digitTapped("5")
                }) {
                    Text("5")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.digitTapped("6")
                }) {
                    Text("6")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.operandTapped("-")
                }) {
                    Text("⎯")
                        .foregroundColor(.blue)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color(UIColor(named: "OperandsColor")!)) //Using named color
                        .cornerRadius(50.0)
                }
            }.padding(.leading, 10).padding(.trailing, 10)
            .font(.largeTitle)

            HStack {
                Button(action: {
                    self.digitTapped("1")
                }) {
                    Text("1")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.digitTapped("2")
                }) {
                    Text("2")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.digitTapped("3")
                }) {
                    Text("3")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.operandTapped("+")
                }) {
                    Text("＋")
                        .foregroundColor(.blue)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color(UIColor(named: "OperandsColor")!)) //Using named color
                        .cornerRadius(50.0)
                }
            }.padding(.leading, 10).padding(.trailing, 10)
            .font(.largeTitle)
            
            HStack {
                Button(action: {
                    self.digitTapped(".")
                }) {
                    Text(".")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                
                Button(action: {
                    self.digitTapped("0")
                }) {
                    Text("0")
                        .foregroundColor(.white)
                        .frame(width: 70, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color.blue)
                        .cornerRadius(50.0)
                }
                
                Spacer()
                Spacer()
                
                Button(action: {
                    self.calculate()
                    detailedCalculatorTextVisible = false
                }) {
                    Text("＝")
                        .foregroundColor(.blue)
                        .frame(width: .none, height: .none, alignment: .center)
                        .frame(width: 160, height: 70, alignment: .center)
                        .padding(.all, 5.0)
                        .background(Color(UIColor(named: "OperandsColor")!)) //Using named color
                        .cornerRadius(50.0)
                }
            }.padding(.leading, 10).padding(.trailing, 10)
            .font(.largeTitle)
        }.padding(.bottom,10.0)
        .background(Color(UIColor(named: "BackgroundColor")!)) //Using named color
    }

    private func digitTapped(_ number: String) {
        detailedCalculatorTextVisible = true
        if detailedCalculatorText.count >= limitOfDetailedDigits || calculatorText.count >= limitOfDigits {
            //Do nothing
        } else if isTypingNumber && calculatorText.contains(".") && (number == ".") {
            //Do nothing. A number can't contain two '.'
        } else if isTypingNumber {
            calculatorText += number
            detailedCalculatorText += number
        } else if !isTypingNumber && (calculatorText == "0") && (number == "0") {
            calculatorText = number
        } else if !isTypingNumber && (calculatorText == "0") && (detailedCalculatorText == "0") {
            calculatorText = number
            detailedCalculatorText = number
        } else if (calculatorText == "0") && (number == ".") {
            calculatorText += number
            detailedCalculatorText = "0\(number)"
            isTypingNumber = true
        } else if !isTypingNumber {
            calculatorText = number
            detailedCalculatorText += number
            isTypingNumber = true
        }
    }
    
    private func operandTapped(_ operand: String) {
        detailedCalculatorTextVisible = true
        if detailedCalculatorText.count >= limitOfDetailedDigits {
            //Do nothing
        } else if operands.contains(String(calculatorText.last!)) {
            calculatorText = String(calculatorText.dropLast()) //Deleting the operand
            detailedCalculatorText = String(detailedCalculatorText.dropLast()) //Deleting the operand
            calculatorText = operand
            detailedCalculatorText += operand
        } else {
            firstNumber = Double(calculatorText)!
            calculatorText = operand
            detailedCalculatorText += operand
        }
        isTypingNumber = false
        self.operand = operand
    }
    
    private func Ctapped() {
        detailedCalculatorTextVisible = true
        firstNumber = 0.0
        secondNumber = 0.0
        operand = ""
        calculatorText = "0"
        detailedCalculatorText = ""
        isTypingNumber = false
    }
    
    private func copyTapped() {
        UIPasteboard.general.string = calculatorText //Write to clipboard
    }
    
    private func deleteTapped() {
        detailedCalculatorTextVisible = true
        if operands.contains(calculatorText) {
            detailedCalculatorText = String(detailedCalculatorText.dropLast())
            calculatorText = detailedCalculatorText
            isTypingNumber = true
        } else if (calculatorText.count >= 2) {
            calculatorText = String(calculatorText.dropLast())
            detailedCalculatorText = String(detailedCalculatorText.dropLast())
        } else if (calculatorText.count < 2) && (detailedCalculatorText.count < 2) {
            calculatorText = "0"
            detailedCalculatorText = ""
            isTypingNumber = false
        } else if (calculatorText.count < 2) && (detailedCalculatorText.count >= 2) {
            let start = detailedCalculatorText.index(detailedCalculatorText.endIndex, offsetBy: -calculatorText.count-1)
            let end = detailedCalculatorText.index(start, offsetBy: 1)
            let range = start..<end
            let n = detailedCalculatorText[range]
            calculatorText = String(n)
            detailedCalculatorText = String(detailedCalculatorText.dropLast())
        }
    }

    private func calculate() {
        if operands.contains(calculatorText) {
            //Do nothing
        } else {
            isTypingNumber = false
            var result  = 0.0
            
            if isMultiCalculationEnabled() {
                print("MultiCalculation enabled")
                firstNumber = getMultiCalculationResult()
                secondNumber = Double(calculatorText)!
            }
            
            if isAutoCalculationEnabled() { //Checking if calculator is in AutoCalculation mode or not
                firstNumber = Double(calculatorText)!
            } else {
                secondNumber = Double(calculatorText)!
            }
            
            if operand == "+" {
                result = firstNumber + secondNumber
            } else if operand == "-" {
                result = firstNumber - secondNumber
            } else if operand == "x" {
                result = firstNumber * secondNumber
            } else if operand == "/" {
                result = firstNumber / secondNumber
            }
            
            arrangingCalculatedResult(result)
            
            print("AutoCalculation = \(isAutoCalculationEnabled())")
            print("MultiCalculation = \(isMultiCalculationEnabled())")
            print("First number = \(firstNumber)")
            print("Second number = \(secondNumber)")
            print("Result number = \(result), calculatorText = \(calculatorText)")
        }
    }
    
    private func isAutoCalculationEnabled() -> Bool {
        var autoCalculation = true
        
        if detailedCalculatorText.contains("+") || detailedCalculatorText.contains("-") || detailedCalculatorText.contains("x") || detailedCalculatorText.contains("/") {
            autoCalculation = false
        }
        
        return autoCalculation
    }
    
    private func arrangingCalculatedResult(_ result: Double) {
        calculatorText = String(result)
        detailedCalculatorText = String(result)
        let last2chars = String(calculatorText.suffix(2))
        let detailedLast2chars = String(detailedCalculatorText.suffix(2))
        
        if (last2chars == ".0") && (detailedLast2chars == ".0") { //Deleting ",0" of the results that has not decimals
            calculatorText = String(calculatorText.dropLast())
            calculatorText = String(calculatorText.dropLast())
            detailedCalculatorText = String(detailedCalculatorText.dropLast())
            detailedCalculatorText = String(detailedCalculatorText.dropLast())
        }
    }
    
    private func isMultiCalculationEnabled() -> Bool {
        var multiCalculationEnabled = false
        
        let numberOfPlusOccurrences = detailedCalculatorText.filter { $0 == "+" }.count
        let numberOfMinusOccurrences = detailedCalculatorText.filter { $0 == "-" }.count
        let numberOfMultOccurrences = detailedCalculatorText.filter { $0 == "x" }.count
        let numberOfDivOccurrences = detailedCalculatorText.filter { $0 == "/" }.count
        let numberOfOperandsOccurrences = numberOfPlusOccurrences + numberOfMinusOccurrences + numberOfMultOccurrences + numberOfDivOccurrences
        
        if numberOfOperandsOccurrences >= 2 {
            multiCalculationEnabled = true
        }
        
        return multiCalculationEnabled
    }
    
    private func getMultiCalculationResult() -> Double {
        var multiCalculationResult = 0.0
        
        let numberOfCharsToDeleteFromEnd = calculatorText.count + 1
        let firstNumberExpression = detailedCalculatorText.prefix(detailedCalculatorText.count - numberOfCharsToDeleteFromEnd)
        print("Expresion a calcular = \(firstNumberExpression)")
        let solution = NSExpression(format: String(firstNumberExpression)) //Solving a math operation inside a String
        multiCalculationResult = solution.expressionValue(with: nil, context: nil) as! Double
        
        return multiCalculationResult
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
